<script setup>
import { player,monster,init,show,monsterDamage,playerDamage,level } from "./assets/entity/Main.js"
init()
</script>

<template>
  <div class="w-screen h-screen bg-slate-100">
    <div class="grid w-3/4 mx-auto bg-white p-10 text-center justify-center">
      <p class="font-extrabold">ANIMAL BATTLE</p><br/>
      <div>
        <p class="font-semibold">{{ player.name }}<span v-show="show.playerDead" class="text-red-400"> PLAYER IS DEAD</span></p>
        <p>{{ `[ HP:${player.health}` }}<span v-show="show.monsterDamage" class="text-red-400">{{ `-${monsterDamage}`}}</span>{{ ` LEVEL:${level} ]` }}</p>
        <p>{{ `[ CLASS:${player.class} LUCK:${player.luck} CRIT:${player.crit} ]` }}</p>
      </div>
      <div>
        <p class="font-semibold">{{ `${monster.name}` }}<span v-show="show.monsterDead" class="text-red-400"> MONSTER IS DEAD</span></p>
        <p>{{ `[ HP:${monster.health}` }}<span v-show="show.playerDamage" class="text-red-400">{{ `-${playerDamage}`}}</span>{{ ` SCORE:${monster.score} ]` }}</p>
      </div><br/>
      <div class="grid grid-cols-2 gap-x-5 text-white font-semibold ">
        <button @click="player.playerAttack()" class="bg-emerald-400 p-3 shadow-md">PLAYER ATTACK</button>
        <button @click="monster.monsterAttack()" class="bg-red-400 p-3 shadow-md">MONSTER ATTACK</button>
      </div>
    </div>
  </div>
</template>

<style scoped>

</style>
