class Character {
    constructor(character,health,luck,crit) {
      this.character = character 
      this.health = health
      this.luck = luck
      this.crit = crit
    }
}
export { Character }