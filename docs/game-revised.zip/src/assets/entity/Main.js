import { Character } from "./Character.js"
import { Player } from "./Player.js"
import { Monster } from "./Monster.js"
import { ref } from 'vue'
//DEFAULT VALUE
const level = ref(1)
const playerDamage = ref(0)
const monsterDamage =  ref(0)

const player = ref(new Player())
const monster = ref("")
const show = ref({
    monsterDamage: false,
    playerDamage: false,
    playerDead: false,
    monsterDead: false
})

const characters = [
    new Character("Foxster",250,3,0),
    new Character("Bearior",500,1,1),
    new Character("Raccoon",250,0,3)
]
const monsters = [
    new Monster("Monster I",100,10),
    new Monster("Monster I",100,10)
]

function dead(entity,key) {
    if ( entity["health"] <= 0) {
      entity["health"] = 0
      popup(key)
    }
}
function randomCard() {
    const card = [ "A", "2","3","4","5","6","7","8","9","10","J","Q","K"]
    return Math.floor(Math.random()*100)+1
}
function popup(id,delay) {
    show.value[id] = true
    if (delay) setTimeout(() => show.value[id] = false,delay)
}
function init() {
    player.value.name = "RewLegendary"
    monster.value = monsters[0]
    player.value.selectCharacter(0)
}

export { dead, randomCard, popup, init, player,playerDamage,monster,monsterDamage,level,characters,monsters,show }