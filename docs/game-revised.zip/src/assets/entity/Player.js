import { playerDamage,randomCard,characters,monster,popup,dead } from "./Main.js"
class Player {
    constructor() {
        this.name = ""
        this.character = "" 
        this.health = 0
        this.luck = 0
        this.crit = 0
    }  
    playerAttack() {
        playerDamage.value = randomCard()
        monster.value.health -= playerDamage.value
        dead(monster.value,"monsterDead")
        popup("playerDamage",500)
    }
    selectCharacter(characterIndex = 0) {
        for (const key in this) {
          const characterValue = characters?.[characterIndex]?.[key]
          if (characterValue) this[key] = characterValue   
        }
    }
  
}
export { Player }