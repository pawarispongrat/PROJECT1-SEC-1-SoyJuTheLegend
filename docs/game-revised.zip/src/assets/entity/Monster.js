import { monsterDamage,randomCard,player,dead,popup } from "./Main.js"
class Monster {
    constructor(name,health,score) {
      this.name = name
      this.health = health
      this.score = score
    }
    monsterAttack() {
        monsterDamage.value = randomCard()
        player.value.health -= monsterDamage.value
        dead(player.value,"playerDead")
        popup("monsterDamage",500)
  }
}
export { Monster }